import {
  Children,
  Fragment,
  isValidElement,
  createElement,
  useEffect,
  useId,
  useRef,
  useState,
  type ReactNode,
} from "react";
import type { Design } from "../domain/design";
import {
  componentNames,
  patternNames,
  type ComponentName,
} from "../domain/library";
import { designVariables } from "../domain/tokens";
export function RuntimeTheme({
  design,
  children,
}: {
  design: Design;
  children: ReactNode;
}) {
  const root = useRef<HTMLDivElement>(null);
  const scopeId = useId();
  const scope = `[data-tasteprint-scope=${JSON.stringify(scopeId)}]`;
  const [width, setWidth] = useState(1440);
  const variables = designVariables(design);
  useEffect(() => {
    const observer = new ResizeObserver((entries) =>
      setWidth(entries[0].contentRect.width),
    );
    if (root.current) observer.observe(root.current);
    return () => observer.disconnect();
  }, []);
  const layout =
    width < design.compactBreakpoint
      ? "compact"
      : width < design.mediumBreakpoint
        ? "medium"
        : width < design.wideBreakpoint
          ? "regular"
          : "wide";
  // Every interpolated value is an enum or bounded number from designSchema.
  const css =
    componentNames
      .map((name) => {
        const c = design.components[name],
          baseHeight =
            name === "Table" ? design.rowHeight : design.controlHeight,
          size = baseHeight + { sm: -8, md: 0, lg: 8 }[c.size];
        const color =
          c.variant === "solid" ? "var(--color-surface)" : "var(--color-ink)";
        const background =
          c.variant === "solid"
            ? "var(--preview-accent)"
            : c.variant === "subtle"
              ? "var(--color-canvas)"
              : "var(--color-surface)";
        return `${scope} [data-component="${name}"] {--component-height:${size}px; min-height:${size}px; --component-font-size:${design.fontSize + { sm: -2, md: 0, lg: 2 }[c.size]}px; font-size:var(--component-font-size); color:${color}; background:${background}; border:${c.variant === "subtle" ? 0 : 1}px solid var(--preview-accent); border-radius:var(--preview-radius); padding:4px 10px;}`;
      })
      .join("\n") +
    patternNames
      .map((name) => {
        const p = design.patterns[name];
        return (
          `${scope} [data-pattern="${name}"] {display:flex; gap:${p.gap}px; ${["ListPage", "SettingsSection", "FormSection", "EmptyState"].includes(name) ? "flex-direction:column;" : ""}}` +
          `@media(max-width:${design.mediumBreakpoint - 1}px) {${scope} [data-pattern="${name}"] {${p.responsive === "stack" ? "flex-direction:column;align-items:stretch;" : "flex-direction:row;flex-wrap:wrap;"}}}`
        );
      })
      .join("\n");
  return (
    <div
      ref={root}
      data-layout={layout}
      data-reduced-motion={design.reducedMotion}
      className="sample-app runtime-root tasteprint-runtime"
      data-tasteprint-scope={scopeId}
      style={
        {
          ...variables,
          "--preview-shadow": design.shadowAllowed
            .split(/[、,\n]/)
            .map((target) => target.trim())
            .includes("Preview")
            ? variables["--surface-shadow"]
            : "none",
          "--preview-accent": design.accent,
          "--preview-radius": `${design.radius}px`,
          "--preview-space": `${design.spacing}px`,
          "--preview-font": `${design.fontSize}px`,
          "--preview-border": design.border
            ? design.borderColor
            : "transparent",
        } as React.CSSProperties
      }
    >
      <style>{css}</style>
      {children}
    </div>
  );
}
function dialogControls(dialog: HTMLDialogElement) {
  return [
    ...dialog.querySelectorAll<HTMLElement>(
      'a[href], button:not(:disabled), input:not(:disabled), select:not(:disabled), textarea:not(:disabled), [tabindex="0"]',
    ),
  ]
    .filter((el) => {
      if (
        el.closest("dialog") !== dialog ||
        el.tabIndex < 0 ||
        el.matches(":disabled") ||
        !el.getClientRects().length ||
        getComputedStyle(el).visibility !== "visible"
      )
        return false;
      // RuntimeDialog uses showModal: ancestors outside this modal do not
      // make its contents inert. Explicit inert inside it still applies.
      for (
        let ancestor: HTMLElement | null = el;
        ancestor;
        ancestor = ancestor.parentElement
      ) {
        if (ancestor.inert) return false;
        if (ancestor === dialog) break;
      }
      return true;
    })
    .sort((a, b) => {
      const first = a.tabIndex > 0 ? a.tabIndex : Infinity,
        second = b.tabIndex > 0 ? b.tabIndex : Infinity;
      // Stable sorting retains DOM order for equal positive or zero indexes.
      return first === second ? 0 : first - second;
    });
}
export function RuntimeDialog({
  open,
  close,
  onConfirm,
  children,
}: {
  open: boolean;
  close: () => void;
  onConfirm?: () => void;
  children?: ReactNode;
}) {
  const titleId = useId(),
    ref = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const dialog = ref.current!;
    if (open && !dialog.open) dialog.showModal();
    else if (!open && dialog.open) dialog.close();
  }, [open]);
  return (
    <dialog
      ref={ref}
      data-component="Dialog"
      aria-labelledby={titleId}
      onClose={(e) => {
        if (e.target === e.currentTarget) close();
      }}
      onCancel={(e) => {
        if (e.target === e.currentTarget) close();
      }}
      onKeyDown={(e) => {
        if (
          e.key !== "Tab" ||
          (e.target as Element).closest("dialog") !== e.currentTarget
        )
          return;
        const controls = dialogControls(e.currentTarget);
        const first = controls[0],
          last = controls.at(-1);
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last?.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first?.focus();
        }
      }}
    >
      <h2 id={titleId}>Confirm changes</h2>
      {children}
      <button type="button" data-component="Button" autoFocus onClick={close}>
        Cancel
      </button>
      <button
        type="button"
        data-component="Button"
        onClick={onConfirm ?? close}
      >
        Confirm
      </button>
    </dialog>
  );
}
export function RuntimeTabs({
  disabled = false,
  onChange,
}: {
  disabled?: boolean;
  onChange?: (value: string) => void;
}) {
  const id = useId(),
    tabs = ["All projects", "Archived"],
    [active, setActive] = useState(0);
  const select = (index: number) => {
    setActive(index);
    onChange?.(tabs[index]);
  };
  return (
    <div>
      <div role="tablist" aria-label="Project views">
        {tabs.map((name, i) => (
          <button
            type="button"
            key={name}
            id={`${id}-tab-${i}`}
            data-component="Tabs"
            role="tab"
            aria-selected={i === active}
            aria-controls={`${id}-panel`}
            tabIndex={i === active ? 0 : -1}
            disabled={disabled}
            onClick={() => select(i)}
            onKeyDown={(e) => {
              if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(e.key))
                return;
              e.preventDefault();
              const next = e.key === "Home" ? 0 : e.key === "End" ? 1 : 1 - i;
              select(next);
              (
                e.currentTarget.parentElement?.children[next] as HTMLElement
              ).focus();
            }}
          >
            {name}
          </button>
        ))}
      </div>
      <div
        id={`${id}-panel`}
        role="tabpanel"
        aria-labelledby={`${id}-tab-${active}`}
        tabIndex={0}
      >
        {tabs[active]}
      </div>
    </div>
  );
}
export function ComponentSpecimen({
  design,
  name,
}: {
  design: Design;
  name: ComponentName;
}) {
  const [state, setState] = useState("default"),
    [open, setOpen] = useState(false);
  const config = design.components[name];
  useEffect(() => {
    if (!config.states.includes(state as never)) setState("default");
  }, [config, state]);
  const attrs = {
    "data-component": name,
    "data-state": state,
    disabled: state === "disabled",
    "aria-invalid": state === "error" || undefined,
    "aria-busy": state === "loading" || undefined,
  };
  return (
    <RuntimeTheme design={design}>
      <section className="runtime-specimen">
        <h2>{name}</h2>
        <p>{config.usage}</p>
        <label>
          表示状態
          <select
            aria-label="表示状態"
            value={state}
            onChange={(e) => setState(e.target.value)}
          >
            {config.states.map((s) => (
              <option key={s}>{s}</option>
            ))}
          </select>
        </label>
        <div className="specimen-control" data-state={state}>
          {name === "Button" ? (
            <button type="button" {...attrs}>
              {state === "loading" ? "Saving…" : "Save changes"}
            </button>
          ) : name === "Input" ? (
            <label>
              Project name
              <input {...attrs} placeholder="Website redesign" />
            </label>
          ) : name === "Select" ? (
            <label>
              Status
              <select {...attrs}>
                <option>In progress</option>
                <option>Done</option>
              </select>
            </label>
          ) : name === "Checkbox" ? (
            <label>
              <input type="checkbox" {...attrs} />
              Notify me
            </label>
          ) : name === "Tabs" ? (
            <RuntimeTabs disabled={state === "disabled"} />
          ) : name === "Dialog" ? (
            <>
              <button
                type="button"
                data-component="Button"
                onClick={() => setOpen(true)}
              >
                Open dialog
              </button>
              <RuntimeDialog open={open} close={() => setOpen(false)} />
            </>
          ) : name === "Table" ? (
            <table {...attrs}>
              <thead>
                <tr>
                  <th>Project</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Website redesign</td>
                  <td>In progress</td>
                </tr>
              </tbody>
            </table>
          ) : (
            <span {...attrs}>In progress</span>
          )}
          {state === "error" && (
            <p role="alert">入力内容を確認してください。</p>
          )}
          {state === "loading" && <p role="status">Loading…</p>}
        </div>
        <p>利用ルール: {config.rules}</p>
        <p>根拠: {config.rationale}</p>
      </section>
    </RuntimeTheme>
  );
}

// Keep DOM, reading and keyboard order aligned with the saved structure.
export function Pattern({
  design,
  name,
  as = "div",
  children,
  ...props
}: {
  design: Design;
  name?: import("../domain/library").PatternName;
  as?: "div" | "header" | "section" | "form";
} & React.HTMLAttributes<HTMLElement>) {
  const flatten = (nodes: ReactNode): ReactNode[] =>
    Children.toArray(
      Children.map(nodes, (node) =>
        isValidElement<{ children?: ReactNode }>(node) && node.type === Fragment
          ? flatten(node.props.children)
          : node,
      ),
    );
  const slots = name ? design.patterns[name].structure : [];
  const position = (node: ReactNode) => {
    const slot = isValidElement<{ "data-slot"?: string }>(node)
      ? node.props["data-slot"]
      : undefined;
    const index = slots.indexOf(slot ?? "");
    return index < 0 ? slots.length : index;
  };
  return createElement(
    as,
    { ...props, "data-pattern": name },
    flatten(children).sort((a, b) => position(a) - position(b)),
  );
}
